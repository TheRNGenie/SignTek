#!/usr/bin/env python3
"""Fake Casino Sign board: speaks the firmware's line protocol on TCP 3333.
Used to test the Windows app without hardware. Simulates a sign whose header
pins are wired to probe GPIOs so SNIFF returns believable signals."""
import json, socket, threading, random, sys

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 3333
OUT = [23, 19, 18, 5, 32, 25, 0, 22, 16, 17, 26, 4]
cfg = dict(scan_rows=8, refresh_hz=120, brightness=100, pin_data_top=23, pin_data_bot=-1,
           pin_clk=18, pin_lat=19, pin_oe=5, pin_a=32, pin_b=25, pin_c=0, pin_d=-1,
           oe_active_low=True, data_invert=False, addr_invert=False, reverse_cols=False,
           chain_bottom_first=True, configured=False)
state = dict(mode="diag", pattern="corners", text="HELLO", hdr="", ssid="", pass_="",
             host="casinosign", apfb=True, bton=True, btname="CasinoSign-1A2B")
fb = bytearray(192)
conf = dict(ssid="", host="casinosign", ap_fallback="1", bt_on="0", bt_name="CasinoSign-1A2B", tz="PST8PDT,M3.2.0,M11.1.0",
            weather_lat="36.17", weather_lon="-115.14", weather_units="F", weather_label="LAS VEGAS",
            stocks="AAPL,TSLA", crypto="bitcoin,ethereum", jackpot_start="100000", jackpot_rate="7.77",
            bright_cap="100", anim_on="corvette", anim_off="", text_speed="30", mqtt_on="0", mqtt_host="",
            mqtt_port="1883", mqtt_user="", mqtt_prefix="casinosign", mqtt_ha="1", sched_on="0",
            sched_start="08:00", sched_end="23:30")
secrets = dict(pass_="", ap_pass="casinosign", mqtt_pass="", ota_pass="casinosign")
playlist = {"items": [{"t": "anim", "name": "corvette"}, {"t": "text", "text": "HELLO", "fx": "scroll", "d": 0}, {"t": "clock", "d": 8}]}
anims = {"corvette": [(40, "00" * 192)] * 125}
upload = {}
fight = dict(a="", b="", event="", status="", result="", round=0, rounds=3, clock=0, running=False)
gamble = dict(bet=0.0, won=0.0, label="TONIGHT")
power = [True]
# what each sniff GPIO "sees" (cycles so repeated sniffs look different)
sniff_profiles = [(1_200_000, 50, True), (960, 12, True), (480, 50, False), (240, 50, False),
                  (0, 0, False), (0, 100, False), (37_000, 41, True), (960, 90, False)]
sniff_i = [0]

def ok(**k): return dict(ok=True, **k)
def err(m): return dict(ok=False, err=m)

def handle(line):
    parts = line.strip().split(" ", 1)
    cmd = parts[0].upper(); rest = parts[1] if len(parts) > 1 else ""
    if cmd == "PING": return ok(pong="sim")
    if cmd == "INFO":
        return ok(fw="3.0.0-sim", power=power[0], showing="playlist", fs_free=90000, ip="127.0.0.1", host=conf["host"], time_valid=True, chip="ESP32-D0WD-V3", heap=180000, uptime_s=42, mode=state["mode"],
                  scanning=state["mode"] == "run", pattern=state["pattern"], out_pins=OUT,
                  in_only_pins=[39, 35], strap_pins=[0, 5], sign_w=96, sign_h=16,
                  cmd_port=3333, bt_supported=True)
    if cmd == "GET":
        if rest.upper().startswith("HDR"): return ok(hdr=state["hdr"])
        return ok(**cfg)
    if cmd == "SET":
        k, _, v = rest.partition(" ")
        if k not in cfg: return err("unknown key " + k)
        cfg[k] = (v in ("1", "true", "on")) if isinstance(cfg[k], bool) else int(v)
        return ok(**cfg)
    if cmd == "SAVE": cfg["configured"] = True; return ok(saved="cfg")
    if cmd == "MODE":
        if rest: state["mode"] = rest.lower()
        return ok(mode=state["mode"], scanning=state["mode"] == "run")
    if cmd == "PROBE":
        p = rest.split()
        if state["mode"] != "diag": return err("switch to DIAG mode first (MODE DIAG)")
        return ok(gpio=int(p[0]), probe=p[1].upper(), hz=float(p[2]) if len(p) > 2 else 1000, ms=10000)
    if cmd == "ALLOFF": return ok(probe="all off")
    if cmd == "SNIFF":
        hz, duty, noisy = sniff_profiles[sniff_i[0] % len(sniff_profiles)]; sniff_i[0] += 1
        if noisy: duty = max(0, min(100, duty + random.uniform(-8, 8)))
        sat = hz > 2_500_000 / 8
        return ok(gpio=int(rest.split()[0]), ms=100, samples=250000, edges=int(hz * 0.2),
                  high_pct=duty, hz=hz, sample_rate=2_500_000, level=duty > 50, saturated=sat)
    if cmd == "PATTERN": state["pattern"] = rest.lower(); return ok(pattern=state["pattern"], scanning=True)
    if cmd == "TEXT": state["text"] = rest; state["pattern"] = "text"; return ok(text=rest)
    if cmd == "SPEED": return ok(speed=int(rest))
    if cmd == "BITMAP":
        if len(rest) != 384: return err("BITMAP needs exactly 384 hex characters")
        fb[:] = bytes.fromhex(rest); state["pattern"] = "bitmap"; return ok(pattern="bitmap")
    if cmd == "FB": return ok(fb=fb.hex(), pattern=state["pattern"], scanning=True)
    if cmd == "WIFI":
        sub, _, v = rest.partition(" "); sub = sub.upper()
        if sub in ("", "STATUS"):
            return ok(ssid=state["ssid"], has_pass=bool(state["pass_"]), connected=bool(state["ssid"]),
                      ip="192.168.1.77", rssi=-58, host=state["host"], ap_fallback=state["apfb"],
                      ap_active=False, ap_ssid="", ap_ip="0.0.0.0", ap_has_pass=True, mac="24:0A:C4:00:11:22", mqtt_on=conf["mqtt_on"] == "1", mqtt_connected=False)
        if sub == "SCAN":
            return ok(networks=[dict(ssid="HomeNet", rssi=-48, open=False), dict(ssid="Garage", rssi=-71, open=False),
                                dict(ssid="xfinitywifi", rssi=-80, open=True)])
        if sub == "SSID": state["ssid"] = v; return ok(ssid=v)
        if sub == "PASS": state["pass_"] = v; return ok(has_pass=bool(v))
        if sub == "HOST": state["host"] = v; return ok(host=v, note="reboot to apply")
        if sub == "AP": state["apfb"] = v.lower() in ("on", "1"); return ok(ap_fallback=state["apfb"])
        return ok()
    if cmd == "BT":
        sub, _, v = rest.partition(" "); sub = sub.upper()
        if sub in ("ON", "OFF"): state["bton"] = sub == "ON"
        if sub == "NAME": state["btname"] = v
        if sub in ("", "STATUS"): return ok(on=False, active=False, name=state["btname"], supported=False)
        return err("this firmware was built without Bluetooth")
    if cmd == "HDR":
        sub, _, v = rest.partition(" ")
        if sub.upper() == "SET": state["hdr"] = v; return ok(len=len(v))
        return ok(hdr=state["hdr"])
    if cmd == "REBOOT": return ok(reboot="now")
    if cmd == "CONF":
        sub, _, kv = rest.partition(" "); sub = sub.upper()
        if sub in ("", "GET"):
            d = dict(conf); d.update({"has_" + k.rstrip("_"): bool(v) for k, v in secrets.items()}); return ok(**d)
        if sub == "SET":
            k, _, v = kv.partition(" ")
            if k in secrets or k + "_" in secrets: secrets[k if k in secrets else k + "_"] = v; return ok(key=k, note="")
            if k not in conf: return err("unknown setting " + k)
            conf[k] = v; return ok(key=k, note="")
        return err("CONF GET or CONF SET <key> <value>")
    if cmd == "POWER":
        m = rest.upper()
        if m == "ON": power[0] = True
        elif m == "OFF": power[0] = False
        elif m == "TOGGLE": power[0] = not power[0]
        return ok(power=power[0])
    if cmd == "TIME": return ok(valid=True, epoch=0, local="2026-10-31 12:00:00", tz=conf["tz"])
    if cmd in ("SHOW", "PLAY", "NEXT"): return ok(showing="sim item")
    if cmd == "PLAYLIST":
        sub, _, j = rest.partition(" "); sub = sub.upper()
        if sub in ("", "GET"): return ok(playlist=playlist, index=0, override=False, showing="sim")
        if sub == "SET":
            d = json.loads(j); playlist.clear(); playlist.update(d); return ok(items=len(d["items"]))
    if cmd == "ANIM":
        p = rest.split(" ", 3); sub = p[0].upper() if p and p[0] else "LIST"
        if sub == "BEGIN": upload.clear(); upload.update(name=p[1], n=int(p[2]), frames=[]); return ok(name=p[1], frames=int(p[2]))
        if sub == "FRAME":
            if int(p[1]) != len(upload.get("frames", [])): return err("expected frame %d" % len(upload["frames"]))
            if len(p[3]) != 384: return err("frame needs 384 hex characters")
            upload["frames"].append((int(p[2]), p[3])); return ok(frame=int(p[1]))
        if sub == "END":
            if len(upload["frames"]) != upload["n"]: return err("incomplete")
            anims[upload["name"]] = upload["frames"]; return ok(saved=upload["name"], frames=upload["n"], fs_free=80000)
        if sub == "LIST":
            return ok(anims=[dict(name=n, frames=len(f), bytes=8 + len(f) * 194) for n, f in anims.items()], fs_free=80000, fs_total=131072, anim_on=conf["anim_on"], anim_off=conf["anim_off"])
        if sub == "DEL": anims.pop(p[1], None); return ok(deleted=p[1], fs_free=90000)
        if sub == "GET":
            f = anims.get(p[1]); i = int(p[2])
            if not f or i >= len(f): return err("no such frame")
            return ok(name=p[1], frame=i, frames=len(f), delay=f[i][0], hex=f[i][1])
        if sub == "PLAY": return ok(showing="anim " + p[1])
    if cmd == "FIGHT":
        sub, _, j = rest.partition(" "); sub = sub.upper()
        if sub == "SET":
            d = json.loads(j)
            for k in ("a", "b", "event", "status", "result", "round", "rounds", "clock", "running"):
                if k in d: fight[k] = d[k]
        if sub == "CLEAR": fight.update(a="", b="", round=0)
        return ok(**fight)
    if cmd == "GAMBLE":
        p = rest.split(" ", 3); sub = p[0].upper() if p and p[0] else "GET"
        if sub == "SET": gamble.update(bet=float(p[1]), won=float(p[2])); gamble["label"] = p[3] if len(p) > 3 else gamble["label"]
        if sub == "RESET": gamble.update(bet=0.0, won=0.0)
        return ok(bet=gamble["bet"], won=gamble["won"], net=gamble["won"] - gamble["bet"], label=gamble["label"])
    if cmd == "LIVE": return ok(weather="72F SUNNY", ticker="AAPL 231.50 +0.8%  BTC 68210 -1.2%", weather_age_s=30, ticker_age_s=20)
    return err("unknown command " + cmd)

def client(conn):
    f = conn.makefile("rwb", buffering=0)
    conn.sendall(b'{"evt":"hello","fw":"sim"}\n')
    for raw in f:
        line = raw.decode(errors="replace").strip()
        if not line: continue
        print(">>", line[:80], flush=True)
        conn.sendall((json.dumps(handle(line)) + "\n").encode())

def udp():
    u = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); u.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    u.bind(("0.0.0.0", 3334))
    while True:
        data, addr = u.recvfrom(256)
        if data.strip() == b"CASINOSIGN?":
            u.sendto(json.dumps(dict(casinosign=True, name=conf["host"], host=conf["host"], ip="127.0.0.1", port=PORT, fw="3.0.0-sim", power=power[0])).encode(), addr)
threading.Thread(target=udp, daemon=True).start()

s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(("0.0.0.0", PORT)); s.listen(2)
print("sim listening on", PORT, flush=True)
while True:
    c, _ = s.accept()
    threading.Thread(target=client, args=(c,), daemon=True).start()
