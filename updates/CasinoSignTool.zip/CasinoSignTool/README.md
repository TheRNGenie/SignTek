# Casino Sign Tool

**Everything you need to know is inside the app.** Open `CasinoSignTool.exe` and start on the **Start here** tab: it shows where you are in the setup, what to do next, and step-by-step instructions for every part of the project. Every tab also has a **How to use this tab** button, and **? Help** in the top bar opens the instructions for whatever tab you're on.

## Getting started
1. Unzip everything. Keep the `firmware` and `esptool` folders next to `CasinoSignTool.exe`.
2. Run `CasinoSignTool.exe` (Windows 10/11, nothing to install). Windows may show a SmartScreen warning the first time because the exe isn't code-signed: click *More info → Run anyway*.
3. Follow the **Start here** tab.

## Updates
The app checks for a new version each time it opens (from github.com/TheRNGenie/SignTek). When there is one, a yellow **Update available** button appears in the top bar; press it and the app updates itself. Your settings are kept.

## What's in the zip
- `CasinoSignTool.exe`: the app.
- `firmware/`: the sign firmware v3, ready to install from the app's tab 0.
- `esptool/`: Espressif's official flashing tool, used by the app.
- `source/`: the app's source code (build with the .NET 8 SDK: `dotnet build -c Release`).
- `tools/board_sim.py`: a pretend board for trying the app without hardware (`python board_sim.py`; the app finds it automatically).

## For Arduino IDE users (optional)
The firmware source is in `casino_sign_driver/` (all the `.ino` and `.h` files together). Board **ESP32 Dev Module**, Partition Scheme **Minimal SPIFFS (1.9MB APP with OTA/190KB SPIFFS)**. Libraries: LovyanGFX, ArduinoJson 7, PubSubClient. Compiles on Arduino-ESP32 2.0.17 and 3.3.12. The command protocol is in `PROTOCOL.md`.

## Caveats
- Nothing has been tested on the real sign or board yet. The app was tested against the simulator, and the firmware compiles on both ESP32 core versions.
- Bluetooth was left out of the firmware so that WiFi firmware updates fit. WiFi and USB do everything Bluetooth did.
- Fight Night's live data comes from ESPN's public (unofficial) scoreboard feed, which can lag or change. Manual mode always works.
